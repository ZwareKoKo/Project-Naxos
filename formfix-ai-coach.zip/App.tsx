import React, { useState, useRef, useCallback, useEffect } from 'react';
import { LiveClient } from './services/liveClient';
import { AnalysisGraphService } from './services/analysisGraph';
import { authService, User } from './services/authService';
import { db, WorkoutDB } from './services/db';
import { decodeAudioData } from './services/audioUtils'; // Import decode
import CameraView from './components/CameraView';
import AgentVisualizer from './components/AgentVisualizer';
import TranscriptView from './components/TranscriptView';
import AuthPage from './components/AuthPage';
import { AgentState, ChatMessage, Pose, ExerciseType } from './types';
import { Play, Square, AlertCircle, Volume2, VolumeX, Activity, ArrowRight, LogOut, User as UserIcon, History } from 'lucide-react';
import { AUDIO_SAMPLE_RATE } from './constants';

const App: React.FC = () => {
  // Auth State
  const [user, setUser] = useState<User | null>(null);

  // App State
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [agentState, setAgentState] = useState<AgentState>({
    perception: false,
    analysis: false,
    coach: false
  });
  const [isMuted, setIsMuted] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState<ExerciseType>(ExerciseType.SQUAT);
  
  // History State
  const [workoutHistory, setWorkoutHistory] = useState<WorkoutDB[]>([]);
  const [startTime, setStartTime] = useState<number>(0);
  
  // Refs
  const liveClient = useRef<LiveClient | null>(null);
  const analysisGraph = useRef<AnalysisGraphService | null>(null);
  const audioContext = useRef<AudioContext | null>(null);
  
  // Audio Scheduling Refs
  const scheduledEndTime = useRef<number>(0);
  const activeSourceCount = useRef<number>(0);
  
  // Bridge between Analysis and Live Client
  const telemetryRef = useRef<any>({ feedback: null, reps: 0, exercise: 'SQUAT' });

  // Lazy Init Graph
  useEffect(() => {
    analysisGraph.current = new AnalysisGraphService();
  }, []);

  // Fetch history on login
  useEffect(() => {
    if (user) {
        db.workouts.where('userEmail').equals(user.email).reverse().limit(5).toArray()
            .then(setWorkoutHistory);
    }
  }, [user]);

  // Initialize AudioContext for output on interaction
  const initAudioOutput = () => {
    if (!audioContext.current) {
      audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: AUDIO_SAMPLE_RATE,
      });
    }
    if (audioContext.current.state === 'suspended') {
      audioContext.current.resume();
    }
  };

  const handleStart = async () => {
    initAudioOutput();
    setError(null);
    setStartTime(Date.now());
    liveClient.current = new LiveClient();

    try {
      await liveClient.current.connect({
        onOpen: () => {
          setIsConnected(true);
          setAgentState({ perception: true, analysis: true, coach: false });
          // Reset scheduler
          scheduledEndTime.current = 0;
          activeSourceCount.current = 0;
        },
        onClose: () => {
          setIsConnected(false);
          setAgentState({ perception: false, analysis: false, coach: false });
        },
        onError: (err) => {
          setError(err.message);
          setIsConnected(false);
        },
        onTranscript: (text, isUser) => {
          setMessages(prev => {
            const sender = isUser ? 'user' : 'coach';
            const lastMsg = prev[prev.length - 1];
            const isSameSender = lastMsg && lastMsg.sender === sender;
            const isRecent = lastMsg && (new Date().getTime() - lastMsg.timestamp.getTime() < 5000);

            if (isSameSender && isRecent) {
                const updatedMessages = [...prev];
                updatedMessages[prev.length - 1] = {
                    ...lastMsg,
                    text: lastMsg.text + text
                };
                return updatedMessages;
            } else {
                return [...prev, {
                    id: Date.now().toString(),
                    sender,
                    text,
                    timestamp: new Date()
                }];
            }
          });
        },
        onAudioData: async (base64) => {
          if (isMuted || !audioContext.current) return;
          
          try {
              // Decode using the MAIN persistent audio context
              const buffer = await decodeAudioData(base64, audioContext.current, AUDIO_SAMPLE_RATE);
              
              // Schedule Ahead Logic
              const currentTime = audioContext.current.currentTime;
              
              // If we have fallen behind (or just started), reset schedule to now + buffer
              if (scheduledEndTime.current < currentTime) {
                  scheduledEndTime.current = currentTime + 0.05; // 50ms safety buffer
              }

              const source = audioContext.current.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContext.current.destination);
              
              source.start(scheduledEndTime.current);
              scheduledEndTime.current += buffer.duration;

              // Update UI State
              setAgentState(prev => ({ ...prev, coach: true }));
              activeSourceCount.current++;

              source.onended = () => {
                  activeSourceCount.current--;
                  if (activeSourceCount.current === 0) {
                      setAgentState(prev => ({ ...prev, coach: false }));
                  }
              };
          } catch (e) {
              console.error("Audio Decode Error", e);
          }
        }
      }, 
      async () => {
          return telemetryRef.current;
      });

    } catch (e) {
      setError("Failed to start session.");
    }
  };

  const handleStop = async () => {
    if (liveClient.current) {
      await liveClient.current.disconnect();
    }
    
    // Save to DB
    if (user && analysisGraph.current && startTime > 0) {
        const reps = analysisGraph.current.currentState.repCount;
        if (reps > 0) {
            const duration = Math.round((Date.now() - startTime) / 1000);
            await db.workouts.add({
                userEmail: user.email,
                exerciseType: selectedExercise,
                reps: reps,
                durationSeconds: duration,
                timestamp: Date.now()
            });
            // Refresh history
            const history = await db.workouts.where('userEmail').equals(user.email).reverse().limit(5).toArray();
            setWorkoutHistory(history);
        }
    }

    setIsConnected(false);
    setAgentState({ perception: false, analysis: false, coach: false });
    setStartTime(0);
  };

  const handleVideoFrame = useCallback((base64: string) => {
    if (isConnected && liveClient.current) {
      liveClient.current.sendVideoFrame(base64);
    }
  }, [isConnected]);

  const handlePoseDetected = useCallback(async (pose: Pose) => {
      if (isConnected && analysisGraph.current) {
          setAgentState(prev => ({...prev, perception: true}));
          
          // Pass to Graph Agent with current exercise selection
          const feedback = await analysisGraph.current.processFrame(pose, selectedExercise);
          
          setAgentState(prev => ({...prev, analysis: true}));
          
          if (analysisGraph.current) {
              telemetryRef.current = {
                  feedback: feedback,
                  reps: analysisGraph.current.currentState.repCount,
                  exercise: selectedExercise
              };
          }
      }
  }, [isConnected, selectedExercise]);

  const handleLogout = () => {
    handleStop();
    setUser(null);
    setWorkoutHistory([]);
    setMessages([]);
  };

  // --- RENDER AUTH PAGE IF NOT LOGGED IN ---
  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  // --- RENDER MAIN APP ---
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center p-4 md:p-8">
      
      {/* Header */}
      <header className="w-full max-w-6xl flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-emerald-400 to-blue-500 bg-clip-text text-transparent">
            FormFix AI
          </h1>
          <p className="text-slate-400 text-sm">Home Workout Coach</p>
        </div>
        <div className="flex items-center gap-4">
            <div className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-2 ${isConnected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-500'}`} />
                {isConnected ? 'LIVE' : 'OFFLINE'}
            </div>
            
            <div className="h-8 w-px bg-slate-700 mx-2" />
            
            <div className="flex items-center gap-2 text-slate-300">
                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
                    <UserIcon size={16} />
                </div>
                <span className="text-sm font-medium hidden sm:block">{user.name}</span>
            </div>

            <button 
                onClick={handleLogout}
                className="p-2 text-slate-500 hover:text-red-400 transition-colors"
                title="Sign Out"
            >
                <LogOut size={20} />
            </button>
        </div>
      </header>

      {/* Main Content Grid */}
      <main className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Visuals & Agents */}
        <div className="md:col-span-1 lg:col-span-2 space-y-6">
          <CameraView 
            active={isConnected} 
            onFrame={handleVideoFrame} 
            onPoseDetected={handlePoseDetected}
          />

          <AgentVisualizer state={agentState} />
          
          {/* Controls */}
          <div className="flex flex-col gap-4 bg-slate-800/50 p-4 rounded-xl border border-slate-700 backdrop-blur-sm">
            
            {/* Exercise Selector */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {[
                    { type: ExerciseType.SQUAT, label: "Squat" },
                    { type: ExerciseType.PUSHUP, label: "Push-up" },
                    { type: ExerciseType.SITUP, label: "Sit-up" },
                    { type: ExerciseType.JUMPING_JACK, label: "Jumping Jack" }
                ].map((ex) => (
                    <button
                        key={ex.type}
                        onClick={() => setSelectedExercise(ex.type)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                            selectedExercise === ex.type 
                            ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' 
                            : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                        }`}
                    >
                        {ex.type === selectedExercise && <Activity size={16} />}
                        {ex.label}
                    </button>
                ))}
            </div>

            <div className="flex items-center justify-between border-t border-slate-700 pt-4">
                <div className="flex gap-4">
                {!isConnected ? (
                    <button 
                    onClick={handleStart}
                    className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-3 rounded-lg font-bold transition-all shadow-lg shadow-emerald-900/50"
                    >
                    <Play size={20} fill="currentColor" /> Start Session
                    </button>
                ) : (
                    <button 
                    onClick={handleStop}
                    className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-lg font-bold transition-all shadow-lg shadow-red-900/50"
                    >
                    <Square size={20} fill="currentColor" /> Stop Session
                    </button>
                )}
                </div>

                <button 
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3 rounded-lg transition-colors ${isMuted ? 'bg-slate-700 text-red-400' : 'bg-slate-700 text-slate-200 hover:bg-slate-600'}`}
                >
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/50 p-4 rounded-xl text-red-200 flex items-center gap-3">
              <AlertCircle size={20} />
              <p>{error}</p>
            </div>
          )}
        </div>

        {/* Right Column: Chat Transcript & History */}
        <div className="md:col-span-1 lg:col-span-1 flex flex-col h-full min-h-[500px] gap-6">
            <div className="flex-1 bg-slate-800/50 rounded-xl border border-slate-700 backdrop-blur-sm flex flex-col overflow-hidden">
                <div className="p-4 border-b border-slate-700 bg-slate-800/80 flex justify-between items-center">
                    <h3 className="font-bold text-slate-200">Coach Feedback</h3>
                    <span className="text-xs text-slate-400 bg-slate-900 px-2 py-1 rounded">
                        {selectedExercise} Mode
                    </span>
                </div>
                <TranscriptView messages={messages} />
            </div>

            {/* Recent History Section */}
            {workoutHistory.length > 0 && (
                <div className="bg-slate-800/50 rounded-xl border border-slate-700 backdrop-blur-sm p-4">
                    <div className="flex items-center gap-2 mb-3 text-slate-400">
                        <History size={16} />
                        <h3 className="text-xs font-bold uppercase tracking-wider">Recent Workouts</h3>
                    </div>
                    <div className="space-y-2">
                        {workoutHistory.map(w => (
                            <div key={w.id} className="flex justify-between items-center bg-slate-900/50 p-2 rounded-lg text-sm">
                                <div>
                                    <span className="font-bold text-emerald-400">{w.reps} reps</span>
                                    <span className="text-slate-500 mx-1">•</span>
                                    <span className="text-slate-300 capitalize">{w.exerciseType}</span>
                                </div>
                                <span className="text-slate-500 text-xs">
                                    {new Date(w.timestamp).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>

      </main>

      <footer className="mt-12 text-slate-500 text-xs text-center">
        Powered by Gemini Live API • MoveNet • Graph Agents <br/>
        IndexedDB Storage • Secure Login Simulation (Web Crypto API)
      </footer>
    </div>
  );
};

export default App;