export enum AgentStatus {
  IDLE = 'IDLE',
  LISTENING = 'LISTENING',
  ANALYZING = 'ANALYZING',
  SPEAKING = 'SPEAKING',
}

export enum ExerciseType {
  SQUAT = 'SQUAT',
  PUSHUP = 'PUSHUP',
  SITUP = 'SITUP',
  JUMPING_JACK = 'JUMPING_JACK',
}

export interface AgentState {
  perception: boolean;
  analysis: boolean;
  coach: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'coach';
  text: string;
  timestamp: Date;
}

export interface StreamConfig {
  sampleRate: number;
}

export interface Keypoint {
  x: number;
  y: number;
  score?: number;
  name?: string;
}

export interface Pose {
  keypoints: Keypoint[];
  score?: number;
}

export interface AnalysisResult {
  isExercising: boolean;
  exerciseType: string;
  feedback: string | null;
  repCount: number;
}