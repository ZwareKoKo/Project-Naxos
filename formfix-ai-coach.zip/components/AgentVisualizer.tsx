import React from 'react';
import { Eye, Brain, Mic, Activity } from 'lucide-react';
import { AgentState } from '../types';

interface AgentVisualizerProps {
  state: AgentState;
}

const AgentVisualizer: React.FC<AgentVisualizerProps> = ({ state }) => {
  return (
    <div className="flex flex-col gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700 backdrop-blur-sm">
      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
        <Activity size={14} /> Multi-Agent System
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Perception Agent */}
        <div className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${state.perception ? 'bg-blue-500/20 border border-blue-500/50' : 'bg-slate-800/50 border border-transparent opacity-50'}`}>
          <div className={`p-2 rounded-full ${state.perception ? 'bg-blue-500 text-white animate-pulse' : 'bg-slate-700 text-slate-400'}`}>
            <Eye size={20} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-200 truncate">Perception Agent</p>
            <p className="text-xs text-slate-400 truncate">{state.perception ? 'Observing...' : 'Idle'}</p>
          </div>
        </div>

        {/* Analysis Agent */}
        <div className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${state.analysis ? 'bg-purple-500/20 border border-purple-500/50' : 'bg-slate-800/50 border border-transparent opacity-50'}`}>
          <div className={`p-2 rounded-full ${state.analysis ? 'bg-purple-500 text-white animate-spin-slow' : 'bg-slate-700 text-slate-400'}`}>
            <Brain size={20} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-200 truncate">Analysis Agent</p>
            <p className="text-xs text-slate-400 truncate">{state.analysis ? 'Thinking...' : 'Waiting'}</p>
          </div>
        </div>

        {/* Coach Agent */}
        <div className={`flex items-center gap-3 p-3 rounded-lg transition-all duration-300 ${state.coach ? 'bg-emerald-500/20 border border-emerald-500/50' : 'bg-slate-800/50 border border-transparent opacity-50'}`}>
          <div className={`p-2 rounded-full ${state.coach ? 'bg-emerald-500 text-white animate-bounce' : 'bg-slate-700 text-slate-400'}`}>
            <Mic size={20} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-slate-200 truncate">Coach Agent</p>
            <p className="text-xs text-slate-400 truncate">{state.coach ? 'Speaking...' : 'Listening'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentVisualizer;