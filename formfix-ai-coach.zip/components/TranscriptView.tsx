import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { User, Dumbbell } from 'lucide-react';

interface TranscriptViewProps {
  messages: ChatMessage[];
}

const TranscriptView: React.FC<TranscriptViewProps> = ({ messages }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 h-full overflow-y-auto scrollbar-hide p-4 space-y-4">
      {messages.length === 0 && (
        <div className="text-center text-slate-500 mt-10">
          <p>Start a session to begin analysis.</p>
        </div>
      )}
      {messages.map((msg) => (
        <div 
          key={msg.id} 
          className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            msg.sender === 'user' ? 'bg-slate-700 text-slate-300' : 'bg-emerald-600 text-white'
          }`}>
            {msg.sender === 'user' ? <User size={16} /> : <Dumbbell size={16} />}
          </div>
          
          <div className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm whitespace-pre-wrap ${
            msg.sender === 'user' 
              ? 'bg-slate-700 text-slate-200 rounded-tr-none' 
              : 'bg-emerald-600/20 text-emerald-100 border border-emerald-600/30 rounded-tl-none'
          }`}>
            {msg.text}
          </div>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  );
};

export default TranscriptView;