import React, { useRef, useEffect, useState } from 'react';
import { Camera, CameraOff } from 'lucide-react';
import { blobToBase64 } from '../services/audioUtils';
import { PoseService, POSE_CONNECTIONS } from '../services/poseService';
import { Pose } from '../types';

interface CameraViewProps {
  active: boolean;
  onFrame: (base64: string) => void;
  onPoseDetected: (pose: Pose) => void;
}

const CameraView: React.FC<CameraViewProps> = ({ active, onFrame, onPoseDetected }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);
  const poseService = useRef<PoseService>(new PoseService());
  const requestRef = useRef<number | null>(null);
  const lastProcessTime = useRef<number>(0);

  useEffect(() => {
    // Initialize MoveNet
    poseService.current.initialize().catch(console.error);

    if (active) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480, facingMode: 'user' } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
            if (videoRef.current) videoRef.current.play();
        };
      }
      
      // Start loops
      lastProcessTime.current = Date.now();
      requestRef.current = requestAnimationFrame(processLoop);
      intervalRef.current = window.setInterval(captureFrameForStream, 1000); // 1 FPS for Gemini Vision
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const stopCamera = () => {
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
      requestRef.current = null;
    }
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const processLoop = async () => {
    if (!active) return;
    
    // Throttle to ~10 FPS (100ms) to prevent GPU overload and context loss
    const now = Date.now();
    if (now - lastProcessTime.current < 100) {
        requestRef.current = requestAnimationFrame(processLoop);
        return;
    }

    if (videoRef.current && videoRef.current.readyState === 4) {
        lastProcessTime.current = now;
        // Detect Pose
        const pose = await poseService.current.estimatePose(videoRef.current);
        if (pose) {
            drawPose(pose);
            onPoseDetected(pose);
        }
    }
    requestRef.current = requestAnimationFrame(processLoop);
  };

  const drawPose = (pose: Pose) => {
      if (!canvasRef.current || !videoRef.current) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      
      // Mirror transform
      ctx.save();
      ctx.scale(-1, 1);
      ctx.translate(-canvasRef.current.width, 0);

      // Draw Keypoints
      pose.keypoints.forEach(kp => {
          if ((kp.score || 0) > 0.3) {
              ctx.beginPath();
              ctx.arc(kp.x, kp.y, 5, 0, 2 * Math.PI);
              ctx.fillStyle = '#10b981'; // Emerald 500
              ctx.fill();
          }
      });

      // Draw Skeleton
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 2;
      POSE_CONNECTIONS.forEach(([i, j]) => {
          const kp1 = pose.keypoints[i];
          const kp2 = pose.keypoints[j];
          if ((kp1.score || 0) > 0.3 && (kp2.score || 0) > 0.3) {
              ctx.beginPath();
              ctx.moveTo(kp1.x, kp1.y);
              ctx.lineTo(kp2.x, kp2.y);
              ctx.stroke();
          }
      });

      ctx.restore();
  };

  const captureFrameForStream = () => {
    if (!videoRef.current) return;
    // Create a temp canvas for frame capture to avoid messing with the drawing canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = videoRef.current.videoWidth;
    tempCanvas.height = videoRef.current.videoHeight;
    const ctx = tempCanvas.getContext('2d');
    
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, tempCanvas.width, tempCanvas.height);
      tempCanvas.toBlob(async (blob) => {
        if (blob) {
          const base64 = await blobToBase64(blob);
          onFrame(base64);
        }
      }, 'image/jpeg', 0.6);
    }
  };

  return (
    <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      {active ? (
        <>
          <video 
            ref={videoRef} 
            playsInline 
            muted 
            className="absolute top-0 left-0 w-full h-full object-cover transform -scale-x-100 opacity-80" 
          />
          <canvas 
            ref={canvasRef} 
            className="absolute top-0 left-0 w-full h-full object-cover"
          />
          <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-500/80 px-3 py-1 rounded-full animate-pulse z-10">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <span className="text-xs font-bold text-white">LIVE</span>
          </div>
        </>
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center text-slate-500">
          <CameraOff size={48} className="mb-4" />
          <p>Camera is off</p>
        </div>
      )}
    </div>
  );
};

export default CameraView;