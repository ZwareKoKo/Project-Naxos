
import { Pose, ExerciseType } from "../types";

// --- Lightweight Graph Runtime (Replaces @langchain/langgraph for browser compatibility) ---
export const START = "__START__";
export const END = "__END__";

type NodeFn<T> = (state: T) => Partial<T>;
type Reducer<T> = (a: T, b: T) => T;

interface ChannelConfig<T> {
    reducer: Reducer<T>;
    default: () => T;
}

class StateGraph<T> {
    private channels: Record<keyof T, ChannelConfig<any>>;
    private nodes: Map<string, NodeFn<T>> = new Map();
    private edges: Map<string, string> = new Map();
    private entryPoint: string = "";

    constructor(config: { channels: Record<keyof T, ChannelConfig<any>> }) {
        this.channels = config.channels;
    }

    addNode(name: string, fn: NodeFn<T>) {
        this.nodes.set(name, fn);
        return this;
    }

    addEdge(from: string, to: string) {
        if (from === START) {
            this.entryPoint = to;
        } else {
            this.edges.set(from, to);
        }
        return this;
    }

    compile() {
        return {
            invoke: async (initialState: Partial<T>): Promise<T> => {
                // 1. Initialize State
                let currentState = {} as T;
                for (const key in this.channels) {
                    const k = key as keyof T;
                    const config = this.channels[k];
                    const initialVal = initialState[k];
                    // Apply reducer if initial value exists, else default
                    currentState[k] = initialVal !== undefined 
                        ? config.reducer(config.default(), initialVal) 
                        : config.default();
                }

                // 2. Run Graph
                let currentNodeName = this.entryPoint;
                
                while (currentNodeName && currentNodeName !== END) {
                    const nodeFn = this.nodes.get(currentNodeName);
                    if (!nodeFn) break;

                    const update = nodeFn(currentState);
                    
                    // Apply updates via reducers
                    for (const key in update) {
                        const k = key as keyof T;
                        const val = update[k];
                        if (val !== undefined) {
                            currentState[k] = this.channels[k].reducer(currentState[k], val);
                        }
                    }

                    currentNodeName = this.edges.get(currentNodeName) || END;
                }

                return currentState;
            }
        };
    }
}
// --------------------------------------------------------------------------

// Define the state of our graph
export interface GraphState {
  pose: Pose | null;
  history: Pose[];
  feedback: string | null;
  exerciseType: ExerciseType;
  isExercising: boolean; // Acts as 'isSquatting' or 'isPushing' etc.
  repCount: number;
  lastFeedbackTime: number;
}

// Heuristic helper functions
function calculateAngle(a: {x:number, y:number}, b: {x:number, y:number}, c: {x:number, y:number}) {
  const radians = Math.atan2(c.y - b.y, c.x - b.x) - Math.atan2(a.y - b.y, a.x - b.x);
  let angle = Math.abs(radians * 180.0 / Math.PI);
  if (angle > 180.0) angle = 360.0 - angle;
  return angle;
}

function calculateDistance(a: {x:number, y:number}, b: {x:number, y:number}) {
    return Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
}

export class AnalysisGraphService {
  private app: any;
  private state: GraphState;
  private initialized: boolean = false;

  constructor() {
    // Initialize State
    this.state = {
      pose: null,
      history: [],
      feedback: null,
      exerciseType: ExerciseType.SQUAT,
      isExercising: false,
      repCount: 0,
      lastFeedbackTime: 0
    };
    
    try {
        this.initializeGraph();
    } catch (e) {
        console.error("Failed to initialize Graph workflow:", e);
    }
  }

  public get currentState(): GraphState {
    return this.state;
  }

  private initializeGraph() {
    // 1. Define Nodes
    const perceptionNode = (state: GraphState) => {
        return {}; // Pass through
    };

    const analysisNode = (state: GraphState) => {
        if (!state.pose || state.pose.keypoints.length === 0) {
             return { feedback: "Step into the camera frame!" };
        }

        const keypoints = state.pose.keypoints;
        const findKp = (name: string) => keypoints.find(k => k.name === name);

        // Common Keypoints
        const nose = findKp('nose');
        const leftShoulder = findKp('left_shoulder');
        const rightShoulder = findKp('right_shoulder');
        const leftElbow = findKp('left_elbow');
        const leftWrist = findKp('left_wrist');
        const rightWrist = findKp('right_wrist');
        const leftHip = findKp('left_hip');
        const rightHip = findKp('right_hip');
        const leftKnee = findKp('left_knee');
        const leftAnkle = findKp('left_ankle');
        const rightAnkle = findKp('right_ankle');
        
        let feedback = null;
        let isExercising = state.isExercising;
        let repCount = state.repCount;

        // --- EXERCISE SWITCH ---
        switch (state.exerciseType) {
            
            // --- SQUAT LOGIC (SIDE VIEW) ---
            case ExerciseType.SQUAT: {
                const isVisible = leftHip && leftKnee && leftAnkle && (leftHip.score||0) > 0.3;
                
                if (isVisible) {
                    const kneeAngle = calculateAngle(leftHip!, leftKnee!, leftAnkle!);
                    
                    if (kneeAngle < 130) {
                        if (!isExercising) isExercising = true; // Started descent
                        
                        // Depth Check
                        if (kneeAngle > 100) {
                            feedback = "Go deeper! Hit parallel.";
                        }
                    } else if (kneeAngle > 160) {
                        if (isExercising) {
                            isExercising = false; // Completed rep
                            repCount += 1;
                            feedback = "Good squat!";
                        }
                    }
                } else if (nose && (nose.score||0) > 0.5) {
                    feedback = "Turn your left side to the camera.";
                }
                break;
            }

            // --- PUSHUP LOGIC (SIDE VIEW) ---
            case ExerciseType.PUSHUP: {
                const isVisible = leftShoulder && leftElbow && leftWrist && leftHip && (leftShoulder.score||0) > 0.3;

                if (isVisible) {
                    const elbowAngle = calculateAngle(leftShoulder!, leftElbow!, leftWrist!);
                    const bodyAngle = leftAnkle ? calculateAngle(leftShoulder!, leftHip!, leftAnkle!) : 180;

                    // Form Check: Sagging Hips
                    if (bodyAngle < 150) {
                        feedback = "Keep your body straight! Don't let hips sag.";
                    }

                    // Phase Detection
                    if (elbowAngle < 100) {
                        if (!isExercising) isExercising = true; // Started down phase
                    } else if (elbowAngle > 160) {
                        if (isExercising) {
                            isExercising = false; // Pushed up
                            repCount += 1;
                            feedback = "Good pushup!";
                        }
                    } else if (isExercising && elbowAngle > 90) {
                         // In down phase but not deep enough
                         feedback = "Go lower! Chest to floor.";
                    }
                } else {
                     feedback = "Get into pushup position (left side).";
                }
                break;
            }

            // --- SITUP LOGIC (SIDE VIEW) ---
            case ExerciseType.SITUP: {
                const isVisible = leftShoulder && leftHip && leftKnee && (leftHip.score||0) > 0.3;

                if (isVisible) {
                    // Angle between Torso and Thigh
                    const hipAngle = calculateAngle(leftShoulder!, leftHip!, leftKnee!);
                    
                    if (hipAngle < 60) {
                         if (!isExercising) {
                             isExercising = true; // Reached top
                         }
                    } else if (hipAngle > 100) {
                         if (isExercising) {
                             isExercising = false; // Returned to ground
                             repCount += 1;
                             feedback = "Good situp!";
                         }
                    } else if (isExercising && hipAngle > 70) {
                        // On the way down or struggling up
                        feedback = "All the way up!";
                    }
                } else {
                    feedback = "Lie down, left side to camera.";
                }
                break;
            }

            // --- JUMPING JACK LOGIC (FRONT VIEW) ---
            case ExerciseType.JUMPING_JACK: {
                // Need front view: shoulders, wrists, ankles
                const isVisible = leftShoulder && rightShoulder && leftWrist && rightWrist && leftAnkle && rightAnkle && (leftShoulder.score||0) > 0.3;
                
                if (isVisible) {
                    // Logic:
                    // 1. Hands Up Check: Wrist Y < Shoulder Y (Y increases downwards)
                    const handsUp = (leftWrist!.y < leftShoulder!.y) && (rightWrist!.y < rightShoulder!.y);
                    
                    // 2. Legs Wide Check: Ankle distance vs Shoulder distance
                    const shoulderDist = calculateDistance(leftShoulder!, rightShoulder!);
                    const ankleDist = calculateDistance(leftAnkle!, rightAnkle!);
                    const legsWide = ankleDist > (shoulderDist * 1.5);
                    const legsTogether = ankleDist < (shoulderDist * 1.2);

                    if (handsUp && legsWide) {
                        if (!isExercising) {
                            isExercising = true; // "Star" position reached
                        }
                    } else if (!handsUp && legsTogether) {
                        // "Pencil" position (Arms down, legs together)
                        if (isExercising) {
                            isExercising = false; // Returned to start
                            repCount += 1;
                            feedback = "Good jumping jack!";
                        }
                    } else if (isExercising && !handsUp) {
                         feedback = "Keep hands up in the jump!";
                    }
                } else {
                    feedback = "Face the camera for Jumping Jacks!";
                }
                break;
            }
        }

        return { 
            feedback, 
            isExercising, 
            repCount 
        };
    };

    const coachNode = (state: GraphState) => {
        const now = Date.now();
        // Rate limit feedback to avoid spamming (3s cooldown)
        if (state.feedback && (now - state.lastFeedbackTime > 3000)) {
             return { lastFeedbackTime: now, feedback: `TELEMETRY: ${state.feedback} (Reps: ${state.repCount})` };
        }
        return { feedback: null };
    };

    // 2. Build Graph
    const workflow = new StateGraph<GraphState>({
        channels: {
            pose: { reducer: (a, b) => b ?? a, default: () => null },
            history: { reducer: (a, b) => b ?? a, default: () => [] },
            feedback: { reducer: (a, b) => b ?? a, default: () => null },
            exerciseType: { reducer: (a, b) => b ?? a, default: () => ExerciseType.SQUAT },
            isExercising: { reducer: (a, b) => b ?? a, default: () => false },
            repCount: { reducer: (a, b) => b ?? a, default: () => 0 },
            lastFeedbackTime: { reducer: (a, b) => b ?? a, default: () => 0 },
        }
    })
    .addNode("perception", perceptionNode)
    .addNode("analysis", analysisNode)
    .addNode("coach", coachNode)
    .addEdge(START, "perception")
    .addEdge("perception", "analysis")
    .addEdge("analysis", "coach")
    .addEdge("coach", END);

    this.app = workflow.compile();
    this.initialized = true;
  }

  async processFrame(pose: Pose, selectedExercise: ExerciseType): Promise<string | null> {
    if (!this.initialized) return null;

    // Reset rep count if exercise changes
    let resetReps = {};
    if (this.state.exerciseType !== selectedExercise) {
        resetReps = { repCount: 0, isExercising: false };
    }

    const inputs: Partial<GraphState> = { 
        ...this.state, 
        ...resetReps,
        pose: pose,
        exerciseType: selectedExercise
    };
    
    try {
        const result = await this.app.invoke(inputs);
        this.state = { ...this.state, ...result };
        return result.feedback;
    } catch (e) {
        console.error("Error processing frame through graph:", e);
        return null;
    }
  }
}