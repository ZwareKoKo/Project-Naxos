
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { createAudioBlob, decodeAudioData, blobToBase64 } from './audioUtils';
import { SYSTEM_INSTRUCTION, AUDIO_SAMPLE_RATE, TOOLS } from '../constants';

// Define the type locally as it is not exported by the SDK
type LiveSession = Awaited<ReturnType<GoogleGenAI['live']['connect']>>;

// --- AudioWorklet Processor Code (Inlined for Browser Environment) ---
// This runs on a separate thread to prevent audio glitches when the Main Thread is busy with TensorFlow.
const WORKLET_CODE = `
class PCMProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.bufferSize = 4096; // Buffer ~250ms of audio @ 16kHz
    this.buffer = new Float32Array(this.bufferSize);
    this.index = 0;
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (input.length > 0) {
      const channelData = input[0];
      for (let i = 0; i < channelData.length; i++) {
        this.buffer[this.index++] = channelData[i];
        if (this.index >= this.bufferSize) {
          // Send full buffer to main thread
          this.port.postMessage(this.buffer);
          this.index = 0;
        }
      }
    }
    return true;
  }
}
registerProcessor('pcm-processor', PCMProcessor);
`;

export interface LiveClientCallbacks {
  onOpen: () => void;
  onClose: () => void;
  onAudioData: (base64: string) => void;
  onTranscript: (text: string, isUser: boolean) => void;
  onError: (error: Error) => void;
}

export class LiveClient {
  private client: GoogleGenAI;
  private sessionPromise: Promise<LiveSession> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private audioStream: MediaStream | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private getTelemetry: (() => Promise<any>) | null = null;

  constructor() {
    this.client = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  public async connect(callbacks: LiveClientCallbacks, getTelemetry: () => Promise<any>) {
    const model = 'gemini-2.5-flash-native-audio-preview-09-2025';
    this.getTelemetry = getTelemetry;

    try {
      // Initialize Audio for Input
      // We prioritize standard AudioContext, fallback to webkit for Safari
      this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 16000,
      });

      // Load the AudioWorklet
      // We create a Blob URL from the string code to avoid needing a separate file
      const blob = new Blob([WORKLET_CODE], { type: 'application/javascript' });
      const workletUrl = URL.createObjectURL(blob);
      await this.inputAudioContext.audioWorklet.addModule(workletUrl);

      this.audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });

      // Connect to Gemini Live
      this.sessionPromise = this.client.live.connect({
        model,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: SYSTEM_INSTRUCTION,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          tools: TOOLS,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log('Gemini Live Connection Opened');
            this.startAudioInputStream();
            callbacks.onOpen();
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Tool Calls (The "Pull" mechanism for telemetry)
            if (message.toolCall) {
                this.handleToolCall(message.toolCall);
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
               // Directly pass base64 to App for efficient decoding/scheduling
               callbacks.onAudioData(base64Audio);
            }

            // Handle Transcripts
            if (message.serverContent?.outputTranscription?.text) {
              callbacks.onTranscript(message.serverContent.outputTranscription.text, false);
            }
            if (message.serverContent?.inputTranscription?.text) {
              callbacks.onTranscript(message.serverContent.inputTranscription.text, true);
            }
          },
          onclose: (event) => {
            console.log('Gemini Live Connection Closed', event);
            this.stopAudioInputStream();
            callbacks.onClose();
          },
          onerror: (err) => {
            console.error('Gemini Live Error:', err);
            callbacks.onError(new Error("Network interruption. Check connection."));
          }
        }
      });

    } catch (err) {
      console.error("Failed to connect:", err);
      callbacks.onError(err as Error);
    }
  }

  private async handleToolCall(toolCall: any) {
    if (!this.sessionPromise || !this.getTelemetry) return;

    const functionResponses = [];
    
    for (const fc of toolCall.functionCalls) {
        if (fc.name === 'get_telemetry') {
            const telemetry = await this.getTelemetry();
            console.log("Providing telemetry to Gemini:", telemetry);
            functionResponses.push({
                id: fc.id,
                name: fc.name,
                response: { result: JSON.stringify(telemetry) }
            });
        }
    }

    if (functionResponses.length > 0) {
        this.sessionPromise.then(session => {
            session.sendToolResponse({
                functionResponses: functionResponses
            });
        });
    }
  }

  private startAudioInputStream() {
    if (!this.inputAudioContext || !this.audioStream || !this.sessionPromise) return;

    const source = this.inputAudioContext.createMediaStreamSource(this.audioStream);
    
    // Create AudioWorkletNode using the processor we registered
    this.workletNode = new AudioWorkletNode(this.inputAudioContext, 'pcm-processor');

    // Handle messages from the AudioWorklet (Receive Buffer)
    this.workletNode.port.onmessage = (event) => {
      const inputData = event.data as Float32Array;
      const pcmBlob = createAudioBlob(inputData);
      
      this.sessionPromise?.then((session) => {
        session.sendRealtimeInput({ media: pcmBlob });
      });
    };

    source.connect(this.workletNode);
    this.workletNode.connect(this.inputAudioContext.destination);
  }

  private stopAudioInputStream() {
    if (this.workletNode) {
      this.workletNode.disconnect();
      this.workletNode = null;
    }
    if (this.audioStream) {
      this.audioStream.getTracks().forEach(track => track.stop());
      this.audioStream = null;
    }
    if (this.inputAudioContext) {
      this.inputAudioContext.close();
      this.inputAudioContext = null;
    }
  }

  public async sendVideoFrame(base64Data: string) {
    if (!this.sessionPromise) return;
    
    this.sessionPromise.then((session) => {
      session.sendRealtimeInput({
        media: {
          mimeType: 'image/jpeg',
          data: base64Data
        }
      });
    });
  }

  public async disconnect() {
    if (this.sessionPromise) {
      const session = await this.sessionPromise;
      try {
        // @ts-ignore
        session.close();
      } catch (e) {
        console.warn("Could not close session gracefully", e);
      }
      this.sessionPromise = null;
    }
    this.stopAudioInputStream();
  }
}
