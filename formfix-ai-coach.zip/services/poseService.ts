import * as tf from '@tensorflow/tfjs';
import * as poseDetection from '@tensorflow-models/pose-detection';
import { Pose, Keypoint } from '../types';

export class PoseService {
  private detector: poseDetection.PoseDetector | null = null;
  private modelLoaded: boolean = false;
  private static initializationPromise: Promise<void> | null = null;

  async initialize() {
    if (this.modelLoaded) return;
    
    // Prevent multiple concurrent initialization calls
    if (PoseService.initializationPromise) {
        await PoseService.initializationPromise;
        return;
    }

    PoseService.initializationPromise = (async () => {
        try {
            // Force WebGL backend to avoid WebGPU instability ('mapAsync' errors)
            // Check if backend is already set to avoid warnings
            if (tf.getBackend() !== 'webgl') {
                await tf.setBackend('webgl');
            }
            await tf.ready();
            console.log("TensorFlow Backend:", tf.getBackend());

            const detectorConfig = {
              modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
              enableSmoothing: true,
            };
            this.detector = await poseDetection.createDetector(
              poseDetection.SupportedModels.MoveNet,
              detectorConfig
            );
            this.modelLoaded = true;
            console.log('MoveNet Model Loaded');
        } catch (e) {
            console.error("Failed to initialize PoseService:", e);
            throw e;
        }
    })();

    await PoseService.initializationPromise;
  }

  async estimatePose(video: HTMLVideoElement): Promise<Pose | null> {
    if (!this.detector || !this.modelLoaded) return null;

    try {
      const poses = await this.detector.estimatePoses(video, {
        maxPoses: 1,
        flipHorizontal: false,
      });

      if (poses.length > 0) {
        return poses[0] as unknown as Pose;
      }
    } catch (error) {
      // Suppress disposal errors that occur during hot-reload or fast switching
      if ((error as Error).message.includes('backend')) {
          console.warn('Backend lost, skipping frame');
      } else {
          console.error('Pose detection error:', error);
      }
    }
    return null;
  }

  // Helper to get specific keypoint
  getKeypoint(pose: Pose, name: string): Keypoint | undefined {
    return pose.keypoints.find((kp) => kp.name === name);
  }
}

export const POSE_CONNECTIONS = poseDetection.util.getAdjacentPairs(poseDetection.SupportedModels.MoveNet);