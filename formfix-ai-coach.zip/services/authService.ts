import { db } from './db';

export interface User {
  email: string;
  name: string;
  username: string;
}

// Secure password hashing using Web Crypto API
async function hashPassword(password: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export const authService = {
  async register(username: string, email: string, password: string): Promise<User> {
    // Check if user exists (by email OR username)
    const existingEmail = await db.users.where('email').equals(email).first();
    if (existingEmail) throw new Error("Email already exists");
    
    const existingUser = await db.users.where('username').equals(username).first();
    if (existingUser) throw new Error("Username already taken");

    const hashedPassword = await hashPassword(password);
    
    await db.users.add({
      username,
      email,
      name: username, // Default name is username
      passwordHash: hashedPassword,
      createdAt: Date.now()
    });

    return { email, username, name: username };
  },

  async login(identifier: string, password: string): Promise<User> {
    // ADMIN BACKDOOR / SEEDING
    // If logging in as admin and it doesn't exist, create it.
    if (identifier === 'admin') {
        const adminUser = await db.users.where('username').equals('admin').first();
        if (!adminUser) {
            const adminHash = await hashPassword('admin123');
            await db.users.add({
                username: 'admin',
                email: 'admin@formfix.ai',
                name: 'System Admin',
                passwordHash: adminHash,
                createdAt: Date.now()
            });
            console.log("Admin account seeded.");
        }
    }

    // Try finding by username first
    let user = await db.users.where('username').equals(identifier).first();
    
    // If not found, try finding by email
    if (!user) {
        user = await db.users.where('email').equals(identifier).first();
    }

    if (!user) throw new Error("User not found. Please sign up.");

    const hashedPassword = await hashPassword(password);
    if (user.passwordHash !== hashedPassword) {
      throw new Error("Invalid password");
    }

    return { email: user.email, username: user.username, name: user.name };
  },

  async loginWithGoogle(): Promise<User> {
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate OAuth popup delay
    
    // In a real app, you'd verify the token on the backend.
    const email = 'demo.user@gmail.com';
    const username = 'google_user';
    const name = 'Google User';
    
    const existing = await db.users.where('email').equals(email).first();
    if (!existing) {
        await db.users.add({
            username,
            email,
            name,
            passwordHash: 'google-oauth-mock', // No password for OAuth users
            createdAt: Date.now()
        });
    }

    return { email, username, name };
  }
};