import Dexie, { Table } from 'dexie';

export interface UserDB {
  id?: number; // Auto-incremented
  username: string;
  email: string;
  name: string; // Display name (derived from username or email)
  passwordHash: string; // SHA-256
  createdAt: number;
}

export interface WorkoutDB {
  id?: number;
  userEmail: string;
  exerciseType: string;
  reps: number;
  durationSeconds: number;
  timestamp: number;
}

class FormFixDatabase extends Dexie {
  users!: Table<UserDB, number>;
  workouts!: Table<WorkoutDB, number>;

  constructor() {
    super('FormFixDB');
    
    // Version 1
    (this as any).version(1).stores({
      users: '++id, &email', 
      workouts: '++id, userEmail, timestamp'
    });

    // Version 2: Add username field and index
    (this as any).version(2).stores({
      users: '++id, &email, &username', // & = unique index
      workouts: '++id, userEmail, timestamp'
    });
  }
}

export const db = new FormFixDatabase();